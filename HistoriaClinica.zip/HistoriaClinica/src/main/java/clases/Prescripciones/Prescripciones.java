/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases.Prescripciones;

import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author Juan Prieto
 */
public class Prescripciones {
    
    private static Prescripciones instancia;
    private ArrayList<String> prescripcionList;

    public Prescripciones() {
        prescripcionList = new ArrayList<>();
    }
    
    public static Prescripciones getInstancia(){
        if (instancia == null) {
            instancia = new Prescripciones();
        }
        return instancia;
    }
    
    public void agregarPrescripciones(String informacion){
        prescripcionList.add(informacion);
        JOptionPane.showMessageDialog(null, "PRESCRIPCION GUARDADA CON EXITO");
    }
    
    public ArrayList<String> obtenerInformacion(){
        return new ArrayList<>(prescripcionList);
        
    }
    
    
    
    
}
