/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases.GestionPacientes;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author Juan Prieto
 */
public class PacienteDaoImplements implements PacienteDao {

    private String driver;
    private String url;
    private String login;
    private String password;
    private String sentencia;
    private Connection connection;
    private Statement statement;
    private ResultSet rs;
    private Paciente paciente;

    public PacienteDaoImplements() {
        this.driver = "org.apache.derby.jdbc.ClientDriver";
        this.url = "jdbc:derby://localhost:1527/sample";
        this.login = "app";
        this.password = "app";
        this.sentencia = "";
        this.connection = null;
        this.statement = null;
        this.rs = null;
        paciente = new Paciente();
    }

    public void conectar() {
        try {
            Class.forName(driver);
            connection = DriverManager.getConnection(url, login, password);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(PacienteDaoImplements.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Error 1-" + ex.getMessage());
        } catch (SQLException ex2) {
            Logger.getLogger(PacienteDaoImplements.class.getName()).log(Level.SEVERE, null, ex2);
            System.out.println("Error 2-" + ex2.getMessage());
        }

        System.out.println("CONEXION EXITOSA");

    }

    public void desconectar() {
        try {
            connection.close();
        } catch (SQLException ex2) {
            Logger.getLogger(PacienteDaoImplements.class.getName()).log(Level.SEVERE, null, ex2);
            System.out.println("Error 2-" + ex2.getMessage());
        }
    }

    @Override
    public List<Paciente> getAllPacientes() {

        if (connection == null) {
            conectar();
        }
        List<Paciente> lista = new ArrayList<>();
        sentencia = "SELECT * FROM APP.PACIENTE";
        try {
            statement = connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            rs = statement.executeQuery(sentencia);
            if (rs == null) {
                JOptionPane.showMessageDialog(null, "NO HAY DATOS");
            }
            rs.first();
            do {
                System.out.println("Ingreso a añadir paciente: " + rs.getInt(1));
                paciente.setId(rs.getInt(1));
                paciente.setNombre(rs.getString(2));
                paciente.setApellidos(rs.getString(3));
                paciente.setFechaNacimiento(rs.getString(4));
                paciente.setGenero(rs.getString(5));
                paciente.setDireccion(rs.getString(6));
                paciente.setTelefono(rs.getString(7));
                paciente.seteMail(rs.getString(8));
                lista.add(paciente);
            } while (rs.next());

        } catch (SQLException ex) {
            Logger.getLogger(PacienteDaoImplements.class.getName()).log(Level.SEVERE, null, ex);
        }
        return lista;
    }

    @Override
    public void updatePaciente(Paciente pac) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void deletePaciente(int pacienteId) {
        if (connection == null) {
            conectar();
        }

        // Construye la sentencia SQL para eliminar un paciente por su ID
        sentencia = "DELETE FROM PACIENTE WHERE ID = " + pacienteId;

        System.out.println(">>>Eliminando al paciente con ID " + pacienteId + ": " + sentencia);
        try {
            statement = connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            statement.executeUpdate(sentencia);
            System.out.println("Paciente eliminado correctamente");
        } catch (SQLException ex) {
            Logger.getLogger(PacienteDaoImplements.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void addPaciente(Paciente pac) {
        if (connection == null) {
            conectar();
        }
        sentencia = "INSERT INTO paciente VALUES("
                + pac.getId() + ",'"
                + pac.getNombre() + "','"
                + pac.getApellidos() + "','"
                + pac.getFechaNacimiento() + "','"
                + pac.getGenero() + "','"
                + pac.getDireccion() + "','"
                + pac.getTelefono() + "','"
                + pac.geteMail() + "')";

        System.out.println(">>>Agregando al paciente: " + sentencia);
        try {
            statement = (Statement) connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            statement.executeUpdate(sentencia);
        } catch (SQLException ex) {
            Logger.getLogger(PacienteDaoImplements.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public Paciente searchPaciente(int pacienteId) {
        if (connection == null) {
            conectar();
        }

        Paciente paciente = null;
        String sentencia = "SELECT * FROM PACIENTE WHERE ID = " + pacienteId;

        System.out.println(">>>Consultando paciente con ID " + pacienteId + ": " + sentencia);

        try (Statement statement = connection.createStatement();
                ResultSet resultSet = statement.executeQuery(sentencia)) {

            if (resultSet.next()) {
                paciente = new Paciente();
                paciente.setId(resultSet.getInt("ID"));
                paciente.setNombre(resultSet.getString("NOMBRE"));
                paciente.setApellidos(resultSet.getString("APELLIDOS"));
                paciente.setFechaNacimiento(resultSet.getString("FECHA_NACIMIENTO"));
                paciente.setGenero(resultSet.getString("GENERO"));
                paciente.setDireccion(resultSet.getString("DIRECCION"));
                paciente.setTelefono(resultSet.getString("TELEFONO"));
                paciente.seteMail(resultSet.getString("EMAIL"));
            }

        } catch (SQLException ex) {
            Logger.getLogger(PacienteDaoImplements.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Error al consultar paciente por ID: " + ex.getMessage());
        } finally {
            if (connection != null) {
                try {
                    connection.close();
                    System.out.println("Conexión cerrada");
                } catch (SQLException ex) {
                    Logger.getLogger(PacienteDaoImplements.class.getName()).log(Level.SEVERE, null, ex);
                    System.out.println("Error al cerrar la conexión: " + ex.getMessage());
                }
            }
        }

        return paciente;
    }

}
