/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases.GestionPacientes;

import clases.GestionPacientes.Paciente;
import java.util.List;
/**
 *
 * @author Juan Prieto
 */
public interface PacienteDao {
    
    public List<Paciente> getAllPacientes();
    public void updatePaciente(Paciente pac);
    public void deletePaciente(int id);
    public void addPaciente(Paciente pac);
    public Paciente searchPaciente(int id);
    
}
