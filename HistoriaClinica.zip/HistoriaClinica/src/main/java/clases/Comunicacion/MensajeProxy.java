/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases.Comunicacion;

/**
 *
 * @author Juan Prieto
 */
public class MensajeProxy implements MensajeSubject {
    private MensajeRealSubject realSubject;

    public MensajeProxy() {
    }

    private MensajeRealSubject getRealSubject() {
        if (realSubject == null) {
            realSubject = new MensajeRealSubject();
        }
        return realSubject;
    }

    @Override
    public void guardarMensaje(String mensaje) {
        getRealSubject().guardarMensaje(mensaje);
    }

    @Override
    public String obtenerMensaje(int indice) {
        return getRealSubject().obtenerMensaje(indice);
    }
}
