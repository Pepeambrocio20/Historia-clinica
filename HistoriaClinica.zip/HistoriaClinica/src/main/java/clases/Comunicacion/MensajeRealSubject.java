/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases.Comunicacion;

import java.util.ArrayList;

/**
 *
 * @author Juan Prieto
 */
public class MensajeRealSubject implements MensajeSubject {
    private ArrayList<String> mensajes = new ArrayList<>();

    @Override
    public void guardarMensaje(String mensaje) {
        mensajes.add(mensaje);
    }

    @Override
    public String obtenerMensaje(int indice) {
        if (indice >= 0 && indice < mensajes.size()) {
            return mensajes.get(indice);
        }
        return null;
    }
}
