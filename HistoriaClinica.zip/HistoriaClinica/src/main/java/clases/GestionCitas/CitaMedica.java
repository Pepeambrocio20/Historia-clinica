/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases.GestionCitas;

/**
 *
 * @author Juan Prieto
 */
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.Observable;

import java.util.Observable;

/**
 *
 * @author USUARIO
 */
public class CitaMedica extends Observable {

    private String paciente;
    private String fecha;

    public CitaMedica(String paciente, String fecha) {
        this.paciente = paciente;
        this.fecha = fecha;
    }

    public String getPaciente() {
        return paciente;
    }

    public String getFecha() {
        return fecha;
    }

    public void setPaciente(String paciente) {
        this.paciente = paciente;
        setChanged();
        notifyObservers(this);
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
        setChanged();
        notifyObservers(this);
    }
    
}
