/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases.GestionCitas;

/**
 *
 * @author Juan Prieto
 */
import clases.GestionCitas.CitaObserver;
import clases.GestionCitas.CitaMedica;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import java.util.Observer;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

/**
 *
 * @author USUARIO
 */
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import java.util.Observer;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

/**
 *
 * @author USUARIO
 */
public class GestionCitasMedicas extends JFrame {

    private List<CitaMedica> citas;
    private CitaObserver citaObserver;

    public GestionCitasMedicas() {

        citas = new ArrayList<>();

        // Configuración de la ventana principal
        setTitle("Gestión de Citas Médicas");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Crear componentes de la interfaz
        JLabel labelPaciente = new JLabel("Nombre del Paciente:");
        JTextField textFieldPaciente = new JTextField();
        JLabel labelFecha = new JLabel("Fecha de la Cita:");
        JTextField textFieldFecha = new JTextField();
        JButton btnAgendarCita = new JButton("Agendar Cita");
        JTextArea textAreaCitas = new JTextArea();

        // Configurar el layout
        setLayout(new GridLayout(6, 1));

        // Agregar componentes a la ventana
        add(labelPaciente);
        add(textFieldPaciente);
        add(labelFecha);
        add(textFieldFecha);
        add(btnAgendarCita);
        add(new JScrollPane(textAreaCitas));

        // Configurar el evento para el botón de agendar cita
        btnAgendarCita.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String paciente = textFieldPaciente.getText();
                String fecha = textFieldFecha.getText();
                CitaMedica cita = new CitaMedica(paciente, fecha);
                citas.add(cita);
                actualizarListaCitas(textAreaCitas);
            }
        });

        // Instanciar el observador
        citaObserver = new CitaObserver(textAreaCitas);

        // Actualizar la lista de citas para que cada cita agregue el observador
        actualizarListaCitas(textAreaCitas);

    }

    private void actualizarListaCitas(JTextArea textAreaCitas) {
        textAreaCitas.setText("");
        citas.forEach(cita -> cita.addObserver(citaObserver));
        for (CitaMedica cita : citas) {
            textAreaCitas.append("Paciente: " + cita.getPaciente() + ", Fecha: " + cita.getFecha() + "\n");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new GestionCitasMedicas().setVisible(true);
            }
        });
    }

}