/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases.HistorialMedico;

/**
 *
 * @author Juan Prieto
 */
import java.util.Scanner;

/**
 *
 * @author danie
 */
public class Paciente implements ComponenteHistorial {

    public Paciente(String nombre, int edad, String enfermedad, String tipoSangre) {

    }

    @Override
    public void mostrarInformacion() {
        System.out.println("Nombre: " + nombre + ", Edad: " + edad + ", Enfermedad: " + enfermedad);
    }

    String nombre;
    int edad;
    String enfermedad;
    String tipoSangre;

    public Paciente(String nombre, int edad, String enfermedad) {
        this.nombre = nombre;
        this.edad = edad;
        this.enfermedad = enfermedad;
    }

    @Override
    public String toString() {
        return "Nombre: " + nombre + ", Edad: " + edad + ", Enfermedad: " + enfermedad;
    }


// Método para editar la información de un paciente
    public void editarInformacion() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Editar información del paciente:");
        System.out.println("Nuevo nombre:");
        this.nombre = scanner.nextLine();

        System.out.println("Nueva edad:");
        this.edad = scanner.nextInt();
        scanner.nextLine(); // Consumir la nueva línea después de nextInt

        System.out.println("Nueva enfermedad:");
        this.enfermedad = scanner.nextLine();

        System.out.println("Información actualizada correctamente.");
    }
}
