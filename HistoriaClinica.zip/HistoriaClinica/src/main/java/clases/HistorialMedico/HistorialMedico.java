/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases.HistorialMedico;

/**
 *
 * @author Juan Prieto
 */
import java.util.Scanner;

/**
 *
 * @author danie
 */
public class HistorialMedico {

    public static Paciente get(int numPaciente) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public static int size() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    Scanner scanner = new Scanner(System.in);

    // Definir el tamaño del arreglo para almacenar historiales médicos
    final int TAMANO_ARREGLO = 5;
    Paciente[] historialMedico = new Paciente[TAMANO_ARREGLO];

    // Menú principal
    int opcion;

    
        do {
            System.out.println("\n--- Menu Principal ---");
        System.out.println("1) Agregar paciente al historial");
        System.out.println("2) Mostrar historial medico de un paciente");
        System.out.println("3) Editar historial medico de un paciente");
        System.out.println("0) Salir");
        System.out.print("Ingrese su opcion: ");

        opcion = scanner.nextInt();
        scanner.nextLine(); // Consumir la nueva línea después de nextInt

        switch (opcion) {
            case 1:
                // Agregar información al historial médico
                for (int i = 0; i < TAMANO_ARREGLO; i++) {
                    System.out.println("\nIngrese informacion del paciente:");
                    System.out.println("Nombre:");
                    String nombre = scanner.nextLine();

                    System.out.println("Edad:");
                    int edad = scanner.nextInt();
                    scanner.nextLine(); // Consumir la nueva línea después de nextInt

                    System.out.println("Enfermedad:");
                    String enfermedad = scanner.nextLine();

                    Paciente paciente = new Paciente(nombre, edad, enfermedad);
                    historialMedico[i] = paciente;
                    // Decorar con información de tipo de sangre
                    ComponenteHistorial pacienteConTipoSangre = new DecoradorTipoSangre(paciente, "A+");
                    // Mostrar la información completa del paciente
                    pacienteConTipoSangre.mostrarInformacion();

                    System.out.println("Desea agregar otro paciente? (1: Si, 0: No)");
                    int agregarOtro = scanner.nextInt();
                    scanner.nextLine(); // Consumir la nueva línea después de nextInt

                    if (agregarOtro == 0) {
                        break;
                    }
                }
                break;
            case 2:
                // Mostrar historial médico de un paciente específico
                System.out.println("\nIngrese el numero de paciente cuyo historial desea ver (1 - " + TAMANO_ARREGLO + "):");
                int numPaciente = scanner.nextInt();
                scanner.nextLine(); // Consumir la nueva línea después de nextInt

                if (numPaciente >= 1 && numPaciente <= TAMANO_ARREGLO && historialMedico[numPaciente - 1] != null) {
                    System.out.println("\nHistorial Medico del Paciente " + numPaciente + ":");
                    System.out.println(historialMedico[numPaciente - 1]);
                } else {
                    System.out.println("Numero de paciente no valido o historial medico no disponible.");
                }
                break;
            case 3:
                // Editar historial médico de un paciente específico
                System.out.println("\nIngrese el numero de paciente cuyo historial desea editar (1-" + TAMANO_ARREGLO + "):");
                int numPacienteEditar = scanner.nextInt();
                scanner.nextLine(); // Consumir la nueva línea después de nextInt

                if (numPacienteEditar >= 1 && numPacienteEditar <= TAMANO_ARREGLO && historialMedico[numPacienteEditar - 1] != null) {
                    historialMedico[numPacienteEditar - 1].editarInformacion();
                } else {
                    System.out.println("Numero de paciente no valido o historial medico no disponible.");
                }
                break;
            case 0:
                System.out.println("Saliendo del programa. Hasta luego!");
                break;
            default:
                System.out.println("Opcion no valida, Intentelo de nuevo.");
                break;
        }
    }
    while (opcion

    != 0);

    scanner.close ();
}
