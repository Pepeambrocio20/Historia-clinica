/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases.HistorialMedico;

/**
 *
 * @author Juan Prieto
 */
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;



public class InterfazApp {

    private JTextArea textArea;
    private JTextField nombreField, edadField, enfermedadField, edadNuevaField, tipoSangreField;
    private List<Paciente> historialMedico;

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                InterfazApp interfaz = new InterfazApp();
                interfaz.createAndShowGUI();
            }
        });
    }
   
    private void createAndShowGUI() {
        historialMedico = new ArrayList<>();

        JFrame frame = new JFrame("Historial Médico");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());

        textArea = new JTextArea();
        textArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(textArea);
        frame.add(scrollPane, BorderLayout.CENTER);

        JPanel inputPanel = new JPanel(new GridLayout(6, 2));

        nombreField = new JTextField();
        edadField = new JTextField();
        enfermedadField = new JTextField();
        edadNuevaField = new JTextField();
        tipoSangreField = new JTextField();

        inputPanel.add(new JLabel("Nombre:"));
        inputPanel.add(nombreField);
        inputPanel.add(new JLabel("Edad:"));
        inputPanel.add(edadField);
        inputPanel.add(new JLabel("Enfermedad:"));
        inputPanel.add(enfermedadField);
        inputPanel.add(new JLabel("Tipo de Sangre:"));
        inputPanel.add(tipoSangreField);

        JButton editarButton = new JButton("Editar Paciente");

        editarButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                SwingUtilities.invokeLater(new Runnable() {
                    public void run() {
                        editarPaciente();
                    }
                });
            }
        });

        inputPanel.add(new JLabel(""));
        inputPanel.add(editarButton);

        frame.add(inputPanel, BorderLayout.NORTH);

        JPanel buttonPanel = new JPanel();
        JButton agregarButton = new JButton("Agregar Paciente");
        JButton mostrarButton = new JButton("Mostrar Paciente");

        agregarButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                SwingUtilities.invokeLater(new Runnable() {
                    public void run() {
                        agregarPaciente();
                    }
                });
            }
        });

        mostrarButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                SwingUtilities.invokeLater(new Runnable() {
                    public void run() {
                        mostrarPaciente();
                    }
                });
            }
        });

        buttonPanel.add(agregarButton);
        buttonPanel.add(mostrarButton);

        frame.add(buttonPanel, BorderLayout.SOUTH);

        frame.setSize(500, 400);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    private void agregarPaciente() {
        String nombre = nombreField.getText();
        int edad = Integer.parseInt(edadField.getText());
        String enfermedad = enfermedadField.getText();

        Paciente paciente = new Paciente(nombre, edad, enfermedad);
        historialMedico.add(paciente);

        mostrarInformacion("Paciente Agregado:\n");
        paciente.mostrarInformacion();
        limpiarCampos();
    }

    private void mostrarPaciente() {
        int numPaciente = obtenerNumeroPaciente();
        if (numPaciente != -1 && numPaciente < historialMedico.size()) {
            mostrarInformacion("Mostrar Paciente:\n");
            historialMedico.get(numPaciente).mostrarInformacion();
        } else if (numPaciente != -1) {
            mostrarInformacion("Número de paciente no válido.\n");
        }
    }

     private void editarPaciente() {
        int numPaciente = obtenerNumeroPaciente();
        if (numPaciente != -1 && numPaciente < historialMedico.size()) {
            Paciente paciente = historialMedico.get(numPaciente);
            paciente.editarInformacion();

            mostrarInformacion("Paciente Editado:\n");
            paciente.mostrarInformacion();
        } else if (numPaciente != -1) {
            mostrarInformacion("Número de paciente no válido.\n");
        }
    }

    private int obtenerNumeroPaciente() {
        try {
            String input = JOptionPane.showInputDialog("Ingrese el número de paciente:");
            if (input != null) {
                return Integer.parseInt(input) - 1;  // Restamos 1 porque los números de pacientes comienzan en 1
            } else {
                return -1;  // Usuario canceló la operación
            }
        } catch (NumberFormatException e) {
            return -1;  // Valor no válido
        }
    }

    private void mostrarInformacion(String info) {
        textArea.setText(info);
    }

    private void limpiarCampos() {
        nombreField.setText("");
        edadField.setText("");
        enfermedadField.setText("");
        edadNuevaField.setText("");
        tipoSangreField.setText("");
    }
}

