/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases.HistorialMedico;

/**
 *
 * @author Juan Prieto
 */
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

/**
 *
 * @author danie
*/

public class Consola 
{// Atributos
    private ByteArrayOutputStream baos;
    private PrintStream newPS, oldPS;

    public Consola()
    {// Create a stream to hold the output
        baos  = new ByteArrayOutputStream();
        newPS = new PrintStream(baos);
                
     // IMPORTANT: Save the old System.out!
        oldPS = System.out;
        
     // Tell Java to use your special stream
        System.setOut(newPS);        
    }
    
    public void restablecer()
    {// Put things back
        System.out.flush(); System.setOut(oldPS);   
    } 
    
    public String getConsola() 
    { String text = baos.toString(); baos.reset();
      return text;  
    }
}
