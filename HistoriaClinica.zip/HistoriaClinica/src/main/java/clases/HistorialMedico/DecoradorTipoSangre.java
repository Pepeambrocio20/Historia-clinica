/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases.HistorialMedico;

/**
 *
 * @author Juan Prieto
 */
public class DecoradorTipoSangre implements ComponenteHistorial {
    private ComponenteHistorial componente;
    private String tipoSangre;

    public DecoradorTipoSangre(ComponenteHistorial componente, String tipoSangre) {
        this.componente = componente;
        this.tipoSangre = tipoSangre;
    }

    @Override
    public void mostrarInformacion() {
        componente.mostrarInformacion();
        System.out.println("Tipo de Sangre: " + tipoSangre);
    }

}
