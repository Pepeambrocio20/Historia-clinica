/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

/**
 *
 * @author Juan Prieto
 */
public class Medico {
    
    private int id;
    private String nombre;
    private String especialidad;
    private String numeroLicencia;

    public Medico(int id, String nombre, String especialidad, String numeroLicencia) {
        this.id = id;
        this.nombre = nombre;
        this.especialidad = especialidad;
        this.numeroLicencia = numeroLicencia;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEspecialidad() {
        return especialidad;
    }

    public void setEspecialidad(String especialidad) {
        this.especialidad = especialidad;
    }

    public String getNumeroLicencia() {
        return numeroLicencia;
    }

    public void setNumeroLicencia(String numeroLicencia) {
        this.numeroLicencia = numeroLicencia;
    }
    
    
    
    
}
