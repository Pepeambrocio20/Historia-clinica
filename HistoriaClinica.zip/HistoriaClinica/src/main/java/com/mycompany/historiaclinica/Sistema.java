/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.historiaclinica;

import Paneles.InterfazPrincipal;
import clases.GestionPacientes.Paciente;
import clases.GestionPacientes.PacienteDaoImplements;
import javax.swing.JFrame;

/**
 *
 * @author Juan Prieto
 */
public class Sistema {

    public static void main(String[] args) {

        InterfazPrincipal inter = new InterfazPrincipal();
        inter.setVisible(true);

        PacienteDaoImplements pac = new PacienteDaoImplements();
        pac.conectar();
    }

}
